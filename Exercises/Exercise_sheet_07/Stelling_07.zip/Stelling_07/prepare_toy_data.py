import numpy as np
import matplotlib.pyplot as plt

def prepare_toy_data(N_samples=200, plot_data=False):
    # N_samples: Number of points to sample from the dataset (~300 is sufficient)
    # plot_data: Plots the sampled data points if needed

    # CREATE TRAINING DATA
    means_gaussians = np.asarray([[0, 3], [2.5, 0], [2, 3]])
    labels_gaussians = [0, 0, 1]
    var_gaussians = np.asarray([[[0.1, 0], [0, 2]], [[2, 0], [0, 0.1]], [[0.2, 0.5], [0.5, 2]]])

    # sample points per gaussian
    X_train = []
    labels_train = []
    for i in range(len(means_gaussians)):
        pts_tmp = np.random.multivariate_normal(means_gaussians[i], var_gaussians[i], N_samples)

        if i == 0:
            X_train = pts_tmp
            labels_train = labels_gaussians[i] * np.ones([N_samples, 1])
        else:
            X_train = np.vstack((X_train, pts_tmp))
            labels_train = np.vstack((labels_train, labels_gaussians[i] * np.ones([N_samples, 1])))

    # plot data
    if plot_data:
        fig = plt.figure()
        plt.scatter(X_train[:, 0], X_train[:, 1], c=labels_train[:,0], cmap=plt.cm.jet)
        fig.hold('off')
        fig.savefig('./train_data.png')
        plt.close("all")

    # CREATE TEST DATA

    # sample points per gaussian
    N_samples_test = N_samples
    X_test = []
    labels_test = []
    for i in range(len(means_gaussians)):
        pts_tmp = np.random.multivariate_normal(means_gaussians[i], var_gaussians[i], N_samples_test)

        if i == 0:
            X_test = pts_tmp
            labels_test = labels_gaussians[i] * np.ones([N_samples_test, 1])
        else:
            X_test = np.vstack((X_test, pts_tmp))
            labels_test = np.vstack((labels_test, labels_gaussians[i] * np.ones([N_samples_test, 1])))

    # plot data
    if plot_data:
        fig = plt.figure()
        plt.scatter(X_test[:, 0], X_test[:, 1], c=labels_test[:,0], cmap=plt.cm.jet)
        fig.hold('off')
        fig.savefig('./test_data.png')
        plt.close("all")

    return X_train, X_test, labels_train, labels_test