import numpy as np
import matplotlib.pyplot as plt

def prcurve(predicted_label, true_label):
    
    TP = np.zeros(len(predicted_label))
    FP = np.zeros(len(predicted_label))
    FN = np.zeros(len(predicted_label))


    for i in range(len(predicted_label)):
        if(predicted_label[i]==true_label[i]):
            TP[i]=1
        elif(predicted_label[i]==1 and true_label[i]==0):
            FP[i]=1
        elif(predicted_label[i]==0 and true_label[i]==1):
            FN[i]=1
        
            
    
    recall=TP/(TP+FP)
    precision=TP/(TP+FN)
    precision2=precision.copy()
    i=recall.shape[0]-2

    # interpolation
    while i>=0:
        if precision[i+1]>precision[i]:
            precision[i]=precision[i+1]
        i=i-1

    # plotting
    fig, ax = plt.subplots()
    for i in range(recall.shape[0]-1):
        ax.plot((recall[i],recall[i]),(precision[i],precision[i+1]),'k-',label='',color='red') #vertical
        ax.plot((recall[i],recall[i+1]),(precision[i+1],precision[i+1]),'k-',label='',color='red') #horizontal

    ax.plot(recall,precision2,'k--',color='blue')
    ax.set_xlabel("recall")
    ax.set_ylabel("precision")
    plt.savefig('fig.jpg')
    fig.show()