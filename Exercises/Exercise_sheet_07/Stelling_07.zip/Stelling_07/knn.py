#!/usr/bin/env python2

from prepare_toy_data import prepare_toy_data
import random
import math
import operator
import numpy as np
from collections import Counter


def train(X_train, y_train):
    # do nothing
    return
    
def predict(X_train, y_train, x_test, k):
    # create list for distances and targets
    distances = []
    targets = []
    
    for i in range(len(X_train)):
        subtr = x_test - X_train
        distance = np.sqrt(np.sum(subtr))
        distances.append([distance, i])
        
    distances = sorted(distances)
    
    # make list of the k neighbours' targets
    for i in range(k):
        index = distances[i][1]
        targets.append(y_train[index])
        
    return Counter(targets).most_common(1)[0][0]
    
def kNearestNeighbour(X_train, y_train, X_test, predictions, k):
    # train on the input data
    train(X_train, y_train)
    
    for i in range(len(X_test)):
        predictions.append(predict(X_train, y_train, X_test[i, :], k))
    
def main():
    predictions = []
    X_train, X_test, labels_train, labels_test = prepare_toy_data(300, False)
    k = 2
    kNearestNeighbour(X_train, labels_train, X_test, predictions, k)
    
    predictions = np.asarray(predictions)
    
    accuracy = accuracy_score(labels_test, predictions)
    print('Accuracy of this classifier: ' + accuracy*100 + '%')
	
main()