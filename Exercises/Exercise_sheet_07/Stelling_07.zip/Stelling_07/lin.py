import numpy as np
from prepare_toy_data import prepare_toy_data
from pr import prcurve

class Perceptron(object):
    def __init__(self, eta=0.01, n_iter=10):
        self.eta = eta
        self.n_iter = n_iter

    def fit(self, X, y):

        self.w_ = np.zeros(1 + X.shape[1])
        self.errors_ = []

        
        for _ in range(self.n_iter):
            errors = 0
            for xi, target in zip(X, y):
                update = self.eta * (target - self.predict(xi))
                self.w_[1:] += update * xi
                self.w_[0] += update
                errors += int(update != 0.0)
            self.errors_.append(errors)
        return self

    def net_input(self, X):
        return np.dot(X, self.w_[1:]) + self.w_[0]

    def predict(self, X):
        return np.where(self.net_input(X) >= 0.0, 1, 0)
        
        
        
X_train, X_test, labels_train, labels_test = prepare_toy_data(300, False)
alpha = 0.5
iterations = 20
p = Perceptron(alpha, iterations)

p.fit(np.array(X_train), labels_train)

predicted_test = p.predict(X_test)

prcurve(predicted_test, labels_test)